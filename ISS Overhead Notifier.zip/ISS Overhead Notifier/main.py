import requests
import datetime as dt
import smtplib
import time

MY_LAT = 33.648953 #YOUR LATITUDE HERE
MY_LNG = 73.177007 #YOUR LONGITUDE HERE


my_email = "YOUR EMAIL HERE"
my_password = "YOUR PASSWORD HERE"


parameters = {
    "lat": MY_LAT,
    "lng": MY_LNG,
    "formatted":1

}

def is_iss_overhead():
    iss_response = requests.get(url="http://api.open-notify.org/iss-now.json")
    iss_response.raise_for_status()
    iss_data = iss_response.json()

    iss_latitude = float(iss_data["iss_position"]["latitude"])
    iss_longitude = float(iss_data["iss_position"]["longitude"])

    if abs(MY_LAT - iss_latitude) < 5 and abs(MY_LNG - iss_longitude) < 5:
        return True

def is_dark():
    response = requests.get(url = "https://api.sunrise-sunset.org/json", params=parameters)
    response.raise_for_status()
    data = response.json()
    sunrise =int(data["results"]["sunrise"].split(":")[0])+5
    sunset =int(data["results"]["sunset"].split(":")[0])+5
    time_now = dt.datetime.now().hour
    if time_now <=sunrise or time_now >=sunset:
        return True


while True:
    time.sleep((3600))
    if is_iss_overhead() and is_dark():
        with smtplib.SMTP("smtp.gmail.com") as connection:
            connection.starttls()
            connection.login(user=my_email, password=my_password)
            connection.sendmail(to_addrs=my_email, from_addr=my_email, msg="Subject:Look Up👆\n\nThe ISS is above you in the sky.")

